#!/system/bin/sh
# KernelSU / Magisk 安装脚本

SKIPUNZIP=0

ui_print "- 恒温充电 ThermoCharge"
ui_print "- 设备: $(getprop ro.product.marketname 2>/dev/null)"

ABI=$(getprop ro.product.cpu.abi)
if [ "$ABI" != "arm64-v8a" ]; then
  ui_print "! 需要 arm64-v8a, 当前 $ABI"
  abort "! 架构不支持"
fi

set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
set_perm "$MODPATH/service.sh"   0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755

# 首次安装才写默认配置，升级时保留用户调过的参数
if [ ! -f /data/adb/thermocharge/config.conf ]; then
  mkdir -p /data/adb/thermocharge/log
  cp "$MODPATH/config.conf" /data/adb/thermocharge/config.conf
  ui_print "- 已写入默认配置 /data/adb/thermocharge/config.conf"
else
  ui_print "- 保留已有配置"
  # v1.0.0 -> v1.1.0 迁移：只在用户没改过这两项时才升级
  #   max_ma            15000 -> 20000（原厂快充就是 17.6A，旧默认白让了功率）
  #   startup_grace_ms   1500 -> 20000（插电瞬间写限流会打断快充握手）
  CF=/data/adb/thermocharge/config.conf
  if ! grep -q '^cfg_version=2' "$CF" 2>/dev/null; then
    sed -i 's/^max_ma=15000$/max_ma=20000/' "$CF" 2>/dev/null
    sed -i 's/^startup_grace_ms=1500$/startup_grace_ms=20000/' "$CF" 2>/dev/null
    # 缺项补默认
    grep -q '^startup_grace_ms=' "$CF" 2>/dev/null || \
      echo 'startup_grace_ms=20000' >> "$CF"
    sed -i '/^cfg_version=/d' "$CF" 2>/dev/null
    echo 'cfg_version=2' >> "$CF"
    ui_print "- 配置已迁移到 v1.1.0 (max_ma/startup_grace_ms 若无自定义则更新)"
  fi
fi

ui_print "- 目标温度 43.0C, 上限 45.0C"
ui_print "- 重启生效"
