#!/system/bin/sh
# 卸载时还原系统默认状态, 避免留下被限流的充电器
# 顺序: 先让守护进程自己优雅退出（它的 SIGTERM 处理会还原）,
#       再调二进制 restore 兜底, 最后裸写 sysfs 三重保险。

MODDIR=${0%/*}
BIN=$MODDIR/bin/thermocharge
PIDF=/data/adb/thermocharge/daemon.pid

# 1) 让守护进程优雅退出
if [ -f "$PIDF" ]; then
  PID=$(cat "$PIDF" 2>/dev/null)
  case "$PID" in
    ''|*[!0-9]*) : ;;
    *) kill -TERM "$PID" 2>/dev/null ;;
  esac
  # 给它最多 2 秒走完 do_restore()
  i=0
  while kill -0 "$PID" 2>/dev/null && [ $i -lt 20 ]; do
    sleep 0.1
    i=$((i + 1))
  done
fi

# pid 文件丢失时按命令行兜底
pkill -TERM -f 'bin/thermocharge run' 2>/dev/null
sleep 0.3

# 2) 二进制还在就直接调 restore
[ -x "$BIN" ] && "$BIN" restore 2>/dev/null

# 3) 裸写兜底, 防止二进制损坏或缺失
echo 22000000 > /sys/class/xm_power/charger/charger_thermal/wired_chg_curr 2>/dev/null
echo "user all 22000" > /sys/class/xm_power/charger/charge_interface/ichg_limit 2>/dev/null
echo "user all 0" > /sys/class/xm_power/charger/charge_interface/input_suspend 2>/dev/null
echo "user all 1" > /sys/class/xm_power/charger/charge_interface/charge_enable 2>/dev/null
echo 0 > /sys/class/xm_power/charger/charger_thermal/wired_thermal_remove 2>/dev/null
echo 0 > /sys/class/xm_power/charger/charger_common/stop_handle_charge 2>/dev/null

# 保留配置和日志, 方便事后查看; 彻底清理请手动删 /data/adb/thermocharge
