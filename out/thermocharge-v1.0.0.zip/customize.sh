#!/system/bin/sh
# KernelSU / Magisk 安装脚本

SKIPUNZIP=0

ui_print "- 恒温充电 ThermoCharge"
ui_print "- 设备: $(getprop ro.product.marketname 2>/dev/null)"

ABI=$(getprop ro.product.cpu.abi)
if [ "$ABI" != "arm64-v8a" ]; then
  ui_print "! 需要 arm64-v8a, 当前 $ABI"
  abort "! 架构不支持"
fi

set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
set_perm "$MODPATH/service.sh"   0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755

# 首次安装才写默认配置，升级时保留用户调过的参数
if [ ! -f /data/adb/thermocharge/config.conf ]; then
  mkdir -p /data/adb/thermocharge/log
  cp "$MODPATH/config.conf" /data/adb/thermocharge/config.conf
  ui_print "- 已写入默认配置 /data/adb/thermocharge/config.conf"
else
  ui_print "- 保留已有配置"
fi

ui_print "- 目标温度 43.0C, 上限 45.0C"
ui_print "- 重启生效"
