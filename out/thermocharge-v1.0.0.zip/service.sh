#!/system/bin/sh
# 恒温充电 ThermoCharge —— late_start service
# 职责: 等系统起来 -> 拉起守护进程 -> 崩溃退避重启 -> 模块停用时还原

MODDIR=${0%/*}
DATA=/data/adb/thermocharge
LOG=$DATA/log/supervisor.log
BIN=$MODDIR/bin/thermocharge
CONF=$DATA/config.conf

mkdir -p "$DATA/log"

# /storage 与 zip 都不保留执行位, 这里兜底补一次
chmod 0755 "$BIN" 2>/dev/null
chmod 0755 "$MODDIR"/*.sh 2>/dev/null

log() { echo "$(date '+%m-%d %H:%M:%S') $*" >> "$LOG"; }

# 日志轮转: 超过 256KB 就转存一份
if [ -f "$LOG" ] && [ "$(wc -c < "$LOG" 2>/dev/null || echo 0)" -gt 262144 ]; then
  mv -f "$LOG" "$LOG.old"
fi

# 等开机完成, 最多 120 秒
i=0
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  i=$((i + 1))
  [ $i -gt 240 ] && break
  sleep 0.5
done

# 再等充电节点就绪 (xm_power 是 vendor 服务创建的)
i=0
while [ ! -w /sys/class/xm_power/charger/charge_interface/ichg_limit ]; do
  i=$((i + 1))
  if [ $i -gt 120 ]; then
    log "WARN: ichg_limit 节点未就绪, 仍尝试启动"
    break
  fi
  sleep 0.5
done

# 配置不存在则用模块内默认值
[ -f "$CONF" ] || cp "$MODDIR/config.conf" "$CONF" 2>/dev/null

log "supervisor start (pid $$)"

BACKOFF=2
while true; do
  if [ -f "$MODDIR/disable" ] || [ -f "$MODDIR/remove" ]; then
    log "模块被停用, 退出"
    break
  fi

  START=$(date +%s)
  "$BIN" run >> "$DATA/log/daemon.out" 2>&1
  RC=$?
  RAN=$(( $(date +%s) - START ))

  if [ -f "$MODDIR/disable" ] || [ -f "$MODDIR/remove" ]; then
    log "模块被停用, 退出"
    break
  fi

  log "daemon exit rc=$RC after ${RAN}s"

  # 跑够 60 秒才算稳定, 重置退避
  [ $RAN -ge 60 ] && BACKOFF=2

  # 崩溃后先还原, 别把系统留在被限流的状态
  "$BIN" restore >> "$DATA/log/daemon.out" 2>&1

  # daemon.out 无上限会慢慢吃掉 /data, 超 1MB 就转存
  if [ -f "$DATA/log/daemon.out" ] && \
     [ "$(wc -c < "$DATA/log/daemon.out" 2>/dev/null || echo 0)" -gt 1048576 ]; then
    mv -f "$DATA/log/daemon.out" "$DATA/log/daemon.out.old"
  fi

  log "restart in ${BACKOFF}s"
  sleep $BACKOFF
  BACKOFF=$((BACKOFF * 2))
  [ $BACKOFF -gt 60 ] && BACKOFF=60
done
